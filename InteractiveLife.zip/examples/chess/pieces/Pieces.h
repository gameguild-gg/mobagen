#ifndef CHESS_PIECES_H
#define CHESS_PIECES_H

#include "King.h"
#include "Queen.h"
#include "Rook.h"
#include "Bishop.h"
#include "Knight.h"
#include "Pawn.h"

#endif
