// #define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
//
// #include <doctest/doctest.h>
// #include "engine/Engine.h"
// #include "scene/GameObject.h"
//
////TEST_CASE("Test GameObjects") {
////  auto engine = new Engine();
////  if (engine->Start("Test engine")) {
////    new GameObject(engine);
////    engine->Run();
////  }
////  engine->Exit();
////  delete engine;
////  engine = nullptr;
////}