#include "JohnConway.h"

// Reference: https://playgameoflife.com/info
void JohnConway::Step(World& world) {
  // todo: implement
  //If Less than two Neighbors are alive, set point to dead
  //If 2 or 3 neighbors are alive, stay alive
  //if more than 3 neighbors are alive, set point to dead since overcrowded
  //if a dead point has 3 alive neighbors, becomes alive
}

int JohnConway::CountNeighbors(World& world, Point2D point) {
  // todo: implement
  //Count neighbors

  return 0;
}
