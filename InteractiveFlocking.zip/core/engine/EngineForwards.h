#ifndef MOBAGEN_ENGINE_FORWARDS_H_
#define MOBAGEN_ENGINE_FORWARDS_H_

class Engine;

#endif